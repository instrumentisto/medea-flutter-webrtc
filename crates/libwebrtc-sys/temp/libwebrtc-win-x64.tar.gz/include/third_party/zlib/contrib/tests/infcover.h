#ifndef __INF_COVER_H__
#define __INF_COVER_H__

void cover_support(void);
void cover_wrap(void);
void cover_back(void);
void cover_inflate(void);
void cover_trees(void);
void cover_fast(void);

#endif
