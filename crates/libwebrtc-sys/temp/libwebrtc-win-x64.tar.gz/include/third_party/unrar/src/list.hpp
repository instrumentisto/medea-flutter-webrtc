#ifndef _RAR_LIST_
#define _RAR_LIST_

void ListArchive(CommandData *Cmd);

#endif
