// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef TOOLS_WIN_IDLEWAKEUPS_STDAFX_H_
#define TOOLS_WIN_IDLEWAKEUPS_STDAFX_H_

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

#include <inttypes.h>
#include <stdio.h>
#include <tchar.h>
#include <windows.h>

#endif  // TOOLS_WIN_IDLEWAKEUPS_STDAFX_H_
